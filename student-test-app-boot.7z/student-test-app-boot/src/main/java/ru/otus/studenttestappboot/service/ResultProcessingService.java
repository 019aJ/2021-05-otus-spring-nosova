package ru.otus.studenttestappboot.service;

public interface ResultProcessingService {
    void process();
}
