package ru.otus.studenttestappboot.service;


import ru.otus.studenttestappboot.domain.Question;

import java.util.List;


public interface QuestionService {
    List<Question> questions();
}
